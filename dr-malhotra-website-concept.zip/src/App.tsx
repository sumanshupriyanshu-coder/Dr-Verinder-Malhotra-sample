import { useEffect, useState, type ReactNode } from "react";

// Keep supplied clinic facts and preview-only notes together for easy review.
const clinic = {
  name: "Dr. Verinder Malhotra",
  city: "Brampton",
  province: "Ontario",
  provinceCode: "ON",
  address: {
    street: "157 Queen St E",
    city: "Brampton",
    provinceCode: "ON",
    postalCode: "L6W 3X4",
    country: "Canada",
    countryCode: "CA",
    short: "157 Queen St E, Brampton",
  },
  phone: {
    display: "+1 905-457-0000",
    href: "tel:+19054570000",
    international: "+19054570000",
  },
  listingSnapshot: {
    showInPreview: true,
    rating: "4.3",
    reviewCount: 93,
    source: "Google reviews",
    note: "Supplied Google listing snapshot; not verified live. Confirm before publication.",
  },
  preview: {
    showConceptNotice: true,
    showBiographyPlaceholder: true,
    showPortraitPlaceholder: true,
    showPrivacyPlaceholder: true,
    notice: "This is a proposed website concept, not an official clinic website.",
    biography:
      "Clinic-approved biography, qualifications, and practice information.",
    portrait: "No clinic-approved portrait has been supplied for this preview.",
    privacy: "Clinic-approved privacy information to be added before publication.",
  },
} as const;

const fullAddress = [
  clinic.address.street,
  clinic.address.city,
  `${clinic.address.provinceCode} ${clinic.address.postalCode}`,
  clinic.address.country,
].join(", ");

const mapsSearchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  `${clinic.name}, ${fullAddress}`,
)}`;
const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
  fullAddress,
)}`;
const mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(
  fullAddress,
)}&output=embed`;

type IconName =
  | "arrow"
  | "chevron"
  | "close"
  | "copy"
  | "menu"
  | "pin"
  | "phone"
  | "route";

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="M7 17 17 7M7 7h10v10" />,
    chevron: <path d="m6 9 6 6 6-6" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    copy: (
      <>
        <rect x="8" y="8" width="12" height="12" rx="2" />
        <path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3" />
      </>
    ),
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    phone: (
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.2 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.96.35 1.9.69 2.8a2 2 0 0 1-.45 2.11L8.08 9.92a16 16 0 0 0 6 6l1.29-1.27a2 2 0 0 1 2.11-.45c.9.34 1.84.57 2.8.69A2 2 0 0 1 22 16.92Z" />
    ),
    route: (
      <>
        <circle cx="6" cy="19" r="2" />
        <path d="M8 19h7a3 3 0 0 0 3-3V8" />
        <path d="m14 11 4-4 4 4" />
        <circle cx="6" cy="5" r="2" />
        <path d="M6 7v4a3 3 0 0 0 3 3h2" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      focusable="false"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const navigation = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Patient Information", href: "#patient-information" },
  { label: "Location & Contact", href: "#location" },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [copyMessage, setCopyMessage] = useState("");

  useEffect(() => {
    const elements = Array.from(
      document.querySelectorAll<HTMLElement>(".reveal"),
    );
    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (reduceMotion || !("IntersectionObserver" in window)) {
      elements.forEach((element) => element.classList.add("is-visible"));
      return;
    }

    document.documentElement.classList.add("motion-ready");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -36px 0px" },
    );

    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!copyMessage) return;
    const timeout = window.setTimeout(() => setCopyMessage(""), 4000);
    return () => window.clearTimeout(timeout);
  }, [copyMessage]);

  async function copyAddress() {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(fullAddress);
      } else {
        throw new Error("Clipboard API unavailable");
      }
      setCopyMessage("Address copied to clipboard.");
    } catch {
      try {
        const field = document.createElement("textarea");
        field.value = fullAddress;
        field.setAttribute("readonly", "");
        field.style.position = "fixed";
        field.style.opacity = "0";
        document.body.appendChild(field);
        let didCopy = false;
        try {
          field.select();
          didCopy = document.execCommand("copy");
        } finally {
          field.remove();
        }
        if (!didCopy) throw new Error("Copy was not available");
        setCopyMessage("Address copied to clipboard.");
      } catch {
        setCopyMessage(
          "Copy is unavailable here. Please select the address to copy it.",
        );
      }
    }
  }

  function closeMenu() {
    setMenuOpen(false);
  }

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "MedicalBusiness",
    name: clinic.name,
    telephone: clinic.phone.international,
    address: {
      "@type": "PostalAddress",
      streetAddress: clinic.address.street,
      addressLocality: clinic.address.city,
      addressRegion: clinic.address.provinceCode,
      postalCode: clinic.address.postalCode,
      addressCountry: clinic.address.countryCode,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <a className="skip-link" href="#main-content">
        Skip to content
      </a>

      {clinic.preview.showConceptNotice && (
        <div className="concept-notice" role="note">
          <span className="concept-notice__label">Website concept preview</span>
          <span>{clinic.preview.notice}</span>
        </div>
      )}

      <header className="site-header">
        <div className="site-header__inner page-width">
          <a className="brand" href="#home" onClick={closeMenu}>
            <span className="brand__name">{clinic.name}</span>
            <span className="brand__location">
              {clinic.city}, {clinic.province}
            </span>
          </a>

          <nav
            className={`primary-nav${menuOpen ? " is-open" : ""}`}
            id="site-navigation"
            aria-label="Primary navigation"
          >
            {navigation.map((item) => (
              <a key={item.href} href={item.href} onClick={closeMenu}>
                {item.label}
              </a>
            ))}
            <a
              className="nav-call"
              href={clinic.phone.href}
              onClick={closeMenu}
            >
              <Icon name="phone" size={16} />
              <span>Call the Clinic</span>
            </a>
          </nav>

          <a className="header-call" href={clinic.phone.href}>
            <Icon name="phone" size={16} />
            <span>Call the Clinic</span>
          </a>

          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            aria-controls="site-navigation"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <Icon name={menuOpen ? "close" : "menu"} size={21} />
          </button>
        </div>
      </header>

      <main id="main-content" tabIndex={-1}>
        <section className="hero" id="home" aria-labelledby="hero-title">
          <img
            className="hero__image"
            src="/images/quiet-architecture.jpg"
            alt="Sunlit stone and brick architecture used as a neutral visual; this is not a photograph of the clinic."
            fetchPriority="high"
          />
          <div className="hero__wash" aria-hidden="true" />
          <div className="page-width hero__inner">
            <div className="hero__copy">
              <p className="eyebrow hero__eyebrow">
                <span className="eyebrow__line" aria-hidden="true" />
                {clinic.city}, {clinic.province}
              </p>
              <h1 className="hero__name" id="hero-title">
                {clinic.name}
              </h1>
              <p className="hero__headline">
                Your health deserves a thoughtful conversation.
              </p>
              <p className="hero__intro">
                Contact {clinic.name}&apos;s office for appointment inquiries
                and information about visiting the clinic.
              </p>

              <div className="hero__actions">
                <a className="button button--primary" href={clinic.phone.href}>
                  <Icon name="phone" size={17} />
                  <span>Call the Clinic</span>
                </a>
                <a
                  className="button button--text"
                  href={directionsUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  <span>Get Directions</span>
                  <Icon name="arrow" size={16} />
                </a>
              </div>

              <div className="hero__details">
                <div className="hero__address">
                  <Icon name="pin" size={18} />
                  <span>{fullAddress}</span>
                </div>
                {clinic.listingSnapshot.showInPreview && (
                  <div className="rating-snapshot" aria-label="Supplied listing rating snapshot">
                    <span className="rating-snapshot__score">
                      {clinic.listingSnapshot.rating}/5
                    </span>
                    <span className="rating-snapshot__divider" aria-hidden="true">
                      ·
                    </span>
                    <span>
                      {clinic.listingSnapshot.reviewCount} {clinic.listingSnapshot.source}
                    </span>
                    <span className="rating-snapshot__note">
                      {clinic.listingSnapshot.note}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="quick-info" aria-label="Quick clinic information">
          <div className="page-width quick-info__grid">
            <a className="quick-link reveal" href={clinic.phone.href}>
              <span className="quick-link__icon">
                <Icon name="phone" size={19} />
              </span>
              <span className="quick-link__content">
                <span className="quick-link__label">Call the office</span>
                <span className="quick-link__value">{clinic.phone.display}</span>
                <span className="quick-link__action">
                  Call the clinic <Icon name="arrow" size={14} />
                </span>
              </span>
            </a>

            <a
              className="quick-link reveal"
              href={directionsUrl}
              target="_blank"
              rel="noreferrer"
            >
              <span className="quick-link__icon">
                <Icon name="pin" size={20} />
              </span>
              <span className="quick-link__content">
                <span className="quick-link__label">Find the clinic</span>
                <span className="quick-link__value">{clinic.address.short}</span>
                <span className="quick-link__action">
                  Get directions <Icon name="arrow" size={14} />
                </span>
              </span>
            </a>

            <a className="quick-link reveal" href="#patient-information">
              <span className="quick-link__icon">
                <Icon name="route" size={19} />
              </span>
              <span className="quick-link__content">
                <span className="quick-link__label">Appointment inquiries</span>
                <span className="quick-link__value">
                  Contact the office for availability
                </span>
                <span className="quick-link__action">
                  Patient information <Icon name="arrow" size={14} />
                </span>
              </span>
            </a>
          </div>
        </section>

        <section className="about-section section-pad" id="about" aria-labelledby="about-title">
          <div
            className={`page-width about-section__grid${
              clinic.preview.showPortraitPlaceholder ? "" : " about-section__grid--single"
            }`}
          >
            <div className="about-section__copy reveal">
              <p className="eyebrow">A local point of contact</p>
              <h2 className="section-title" id="about-title">
                Meet {clinic.name}
              </h2>
              <p className="section-lead">
                {clinic.name}&apos;s office is located on Queen Street East in
                {` ${clinic.address.city}, ${clinic.province}.`}
              </p>
              {clinic.preview.showBiographyPlaceholder && (
                <div className="approval-note">
                  <span className="approval-note__label">
                    Preview placeholder · clinic approval needed
                  </span>
                  <p>{clinic.preview.biography}</p>
                  <span className="approval-note__helper">
                    Replace with verified information or remove before launch.
                  </span>
                </div>
              )}
            </div>

            {clinic.preview.showPortraitPlaceholder && (
              <figure className="portrait-placeholder reveal">
                <div className="portrait-placeholder__art" aria-hidden="true">
                  <span className="portrait-placeholder__arch" />
                  <span className="portrait-placeholder__sun" />
                  <span className="portrait-placeholder__stem portrait-placeholder__stem--one" />
                  <span className="portrait-placeholder__stem portrait-placeholder__stem--two" />
                </div>
                <figcaption className="portrait-placeholder__caption">
                  <span className="portrait-placeholder__caption-label">
                    Portrait placeholder
                  </span>
                  <span>{clinic.preview.portrait}</span>
                </figcaption>
              </figure>
            )}
          </div>
        </section>

        <section
          className="patient-section section-pad"
          id="patient-information"
          aria-labelledby="patient-title"
        >
          <div className="page-width">
            <div className="section-heading reveal">
              <p className="eyebrow">Patient information</p>
              <h2 className="section-title" id="patient-title">
                Planning your visit
              </h2>
              <p className="section-lead">
                A quick call is the best way to confirm the details you need.
              </p>
            </div>

            <div className="patient-guidance__grid">
              <a className="guidance-link reveal" href={clinic.phone.href}>
                <span className="guidance-link__number">01</span>
                <span className="guidance-link__body">
                  <span className="guidance-link__title">Appointment availability</span>
                  <span className="guidance-link__text">
                    Please contact the office to ask about appointment availability.
                  </span>
                  <span className="guidance-link__action">
                    Call to ask <Icon name="arrow" size={15} />
                  </span>
                </span>
              </a>

              <a className="guidance-link reveal" href={clinic.phone.href}>
                <span className="guidance-link__number">02</span>
                <span className="guidance-link__body">
                  <span className="guidance-link__title">New patient inquiries</span>
                  <span className="guidance-link__text">
                    Please call the clinic to confirm whether new patients are being accepted.
                  </span>
                  <span className="guidance-link__action">
                    Call to confirm <Icon name="arrow" size={15} />
                  </span>
                </span>
              </a>

              <a className="guidance-link reveal" href={clinic.phone.href}>
                <span className="guidance-link__number">03</span>
                <span className="guidance-link__body">
                  <span className="guidance-link__title">Visit information</span>
                  <span className="guidance-link__text">
                    Contact the office for information about preparing for your visit.
                  </span>
                  <span className="guidance-link__action">
                    Ask the office <Icon name="arrow" size={15} />
                  </span>
                </span>
              </a>
            </div>
          </div>
        </section>

        {clinic.listingSnapshot.showInPreview && (
          <section className="feedback-section section-pad" aria-labelledby="feedback-title">
            <div className="page-width feedback-section__inner reveal">
              <div className="feedback-section__intro">
                <p className="eyebrow">Shared by the supplied listing</p>
                <h2 className="section-title" id="feedback-title">
                  Patient feedback
                </h2>
                <p className="feedback-section__description">
                  A listing snapshot is shown here for preview only. No individual
                  reviews or patient comments have been added.
                </p>
              </div>

              <div className="feedback-section__summary">
                <div className="feedback-section__rating">
                  <span className="feedback-section__score">
                    {clinic.listingSnapshot.rating}
                  </span>
                  <span className="feedback-section__out-of">/ 5</span>
                </div>
                <div className="feedback-section__details">
                  <span className="feedback-section__source">
                    {clinic.listingSnapshot.reviewCount} {clinic.listingSnapshot.source}
                  </span>
                  <span className="feedback-section__note">
                    {clinic.listingSnapshot.note}
                  </span>
                  <a
                    className="text-link"
                    href={mapsSearchUrl}
                    target="_blank"
                    rel="noreferrer"
                  >
                    View on Google Maps <Icon name="arrow" size={15} />
                  </a>
                </div>
              </div>
            </div>
          </section>
        )}

        <section className="location-section section-pad" id="location" aria-labelledby="location-title">
          <div className="page-width">
            <div className="section-heading reveal">
              <p className="eyebrow">Location &amp; contact</p>
              <h2 className="section-title" id="location-title">
                Find the clinic
              </h2>
              <p className="section-lead">
                Get in touch for appointment inquiries and current visit information.
              </p>
            </div>

            <div className="location-section__grid">
              <div className="contact-panel reveal">
                <p className="contact-panel__eyebrow">Contact details</p>
                <p className="contact-panel__name">{clinic.name}</p>
                <address className="contact-panel__address">
                  {clinic.address.street}
                  <br />
                  {clinic.address.city}, {clinic.address.provinceCode} {clinic.address.postalCode}
                  <br />
                  {clinic.address.country}
                </address>

                <a className="contact-panel__phone" href={clinic.phone.href}>
                  <Icon name="phone" size={17} />
                  {clinic.phone.display}
                </a>

                <div className="contact-panel__hours">
                  <span>Opening hours</span>
                  <p>Please call the office to confirm current opening hours.</p>
                </div>

                <div className="contact-panel__actions">
                  <a className="button button--primary" href={clinic.phone.href}>
                    <Icon name="phone" size={16} />
                    <span>Call the Clinic</span>
                  </a>
                  <a
                    className="button button--outline"
                    href={directionsUrl}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Icon name="route" size={17} />
                    <span>Get Directions</span>
                  </a>
                </div>

                <div className="copy-address-row">
                  <button className="copy-button" type="button" onClick={copyAddress}>
                    <Icon name="copy" size={16} />
                    <span>Copy Address</span>
                  </button>
                  <span className="copy-feedback" aria-live="polite" aria-atomic="true">
                    {copyMessage}
                  </span>
                </div>
              </div>

              <div className="map-panel reveal">
                <div className="map-panel__topline">
                  <span>Map &amp; directions</span>
                  <Icon name="pin" size={17} />
                </div>
                {mapLoaded ? (
                  <iframe
                    className="map-frame"
                    src={mapEmbedUrl}
                    title={`Map showing ${fullAddress}`}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    allowFullScreen
                  />
                ) : (
                  <div className="map-placeholder">
                    <div className="map-placeholder__art" aria-hidden="true">
                      <span className="map-placeholder__line map-placeholder__line--one" />
                      <span className="map-placeholder__line map-placeholder__line--two" />
                      <span className="map-placeholder__line map-placeholder__line--three" />
                      <span className="map-placeholder__marker">
                        <Icon name="pin" size={22} />
                      </span>
                    </div>
                    <div className="map-placeholder__content">
                      <span className="map-placeholder__label">Google Maps</span>
                      <p>Load an interactive map for the supplied address.</p>
                      <button
                        className="map-load-button"
                        type="button"
                        onClick={() => setMapLoaded(true)}
                      >
                        Load interactive map <Icon name="arrow" size={15} />
                      </button>
                      <span className="map-placeholder__privacy">
                        Decorative preview; Google Maps loads only when requested.
                      </span>
                    </div>
                  </div>
                )}
                <a
                  className="map-panel__directions"
                  href={directionsUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  Open directions in Google Maps <Icon name="arrow" size={15} />
                </a>
              </div>
            </div>
          </div>
        </section>

        <section className="faq-section section-pad" aria-labelledby="faq-title">
          <div className="page-width faq-section__grid">
            <div className="faq-section__intro reveal">
              <p className="eyebrow">A few helpful details</p>
              <h2 className="section-title" id="faq-title">
                Frequently asked questions
              </h2>
              <p className="section-lead">
                For anything not covered here, please contact the office directly.
              </p>
            </div>

            <div className="faq-list reveal">
              <details className="faq-item">
                <summary>
                  <span>How can I contact the clinic?</span>
                  <span className="faq-item__icon" aria-hidden="true">
                    <Icon name="chevron" size={17} />
                  </span>
                </summary>
                <p>
                  Call the office at <a href={clinic.phone.href}>{clinic.phone.display}</a>.
                </p>
              </details>

              <details className="faq-item">
                <summary>
                  <span>Where is the clinic located?</span>
                  <span className="faq-item__icon" aria-hidden="true">
                    <Icon name="chevron" size={17} />
                  </span>
                </summary>
                <p>{fullAddress}.</p>
              </details>

              <details className="faq-item">
                <summary>
                  <span>Is the clinic accepting new patients?</span>
                  <span className="faq-item__icon" aria-hidden="true">
                    <Icon name="chevron" size={17} />
                  </span>
                </summary>
                <p>Please contact the office directly to confirm.</p>
              </details>

              <details className="faq-item">
                <summary>
                  <span>Are walk-in appointments available?</span>
                  <span className="faq-item__icon" aria-hidden="true">
                    <Icon name="chevron" size={17} />
                  </span>
                </summary>
                <p>Please call the office to ask about visit arrangements.</p>
              </details>

              <details className="faq-item">
                <summary>
                  <span>What are the clinic&apos;s opening hours?</span>
                  <span className="faq-item__icon" aria-hidden="true">
                    <Icon name="chevron" size={17} />
                  </span>
                </summary>
                <p>Please contact the office to confirm current hours.</p>
              </details>
            </div>
          </div>
        </section>

        <section className="final-cta" aria-labelledby="final-cta-title">
          <div className="page-width final-cta__inner reveal">
            <div>
              <p className="eyebrow eyebrow--light">Questions about a visit?</p>
              <h2 id="final-cta-title">Get in touch with the clinic.</h2>
              <p>
                For appointment inquiries and visit information, please call the office.
              </p>
            </div>
            <a className="button button--light" href={clinic.phone.href}>
              <Icon name="phone" size={17} />
              <span>Call {clinic.phone.display}</span>
            </a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="page-width">
          <div className="site-footer__main">
            <div className="site-footer__identity">
              <a className="brand brand--footer" href="#home">
                <span className="brand__name">{clinic.name}</span>
                <span className="brand__location">
                  {clinic.city}, {clinic.province}
                </span>
              </a>
              <address>
                {fullAddress}
                <br />
                <a href={clinic.phone.href}>{clinic.phone.display}</a>
              </address>
            </div>

            <nav className="footer-nav" aria-label="Footer navigation">
              <span className="footer-nav__heading">Explore</span>
              {navigation.map((item) => (
                <a key={item.href} href={item.href}>
                  {item.label}
                </a>
              ))}
            </nav>

            {clinic.preview.showPrivacyPlaceholder && (
              <div className="site-footer__privacy">
                <span className="footer-nav__heading">Privacy information</span>
                <p>{clinic.preview.privacy}</p>
              </div>
            )}
          </div>

          <div className="site-footer__bottom">
            <p>Website information does not replace medical advice.</p>
            <p>For a medical emergency, call 911.</p>
            <span className="site-footer__concept">Website concept preview</span>
          </div>
        </div>
      </footer>

      <nav className="mobile-actions" aria-label="Quick actions">
        <a href={clinic.phone.href}>
          <Icon name="phone" size={17} />
          <span>Call</span>
        </a>
        <a href={directionsUrl} target="_blank" rel="noreferrer">
          <Icon name="route" size={17} />
          <span>Directions</span>
        </a>
      </nav>
    </>
  );
}

export default App;
# Clinic Approval Checklist

This document is for the concept handoff only and is not part of the public-facing website.

Before publication, ask the clinic to confirm or provide:

- Permission to publish this proposed website concept and confirm that the supplied name, phone number, and address are current.
- Whether the supplied 4.3/5 rating and 93-review count are still accurate, and whether the clinic wants this non-live listing snapshot displayed.
- A clinic-approved biography, qualifications, and practice information, or approval to remove the preview placeholder.
- An approved portrait, if desired, or approval to remove the portrait placeholder.
- Current opening hours. The preview intentionally asks visitors to call instead of inferring hours.
- Appointment availability, new-patient status, walk-in arrangements, and any other visit information the clinic wants published.
- Clinic-approved privacy information for the footer. No privacy policy or legal wording is supplied in this concept.
- Confirmation of the Google Maps search and directions links after the clinic verifies the address listing.

No specialties, services, affiliations, credentials, testimonials, insurance details, languages, or clinical outcomes have been added because they were not supplied.